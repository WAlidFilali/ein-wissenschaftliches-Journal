package ma.gestionjournale.gestionjournale_v1.enums;

public enum StatusCompte {
    INACTIF,
    ACTIVE,
    BLOCKE,
    SUSPENDU
}
