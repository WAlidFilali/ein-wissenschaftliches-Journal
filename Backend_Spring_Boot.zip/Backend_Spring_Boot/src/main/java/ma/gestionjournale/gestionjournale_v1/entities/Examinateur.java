package ma.gestionjournale.gestionjournale_v1.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor
public class Examinateur extends Utilisateur{
    private Integer nbr_article_affectes;
    private Integer nbr_article_evalues;

    @OneToMany(mappedBy = "examinateur")
    private List<Recommandation> recommandations;
}
