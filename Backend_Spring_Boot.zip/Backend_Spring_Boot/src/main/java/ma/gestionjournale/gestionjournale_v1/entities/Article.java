package ma.gestionjournale.gestionjournale_v1.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.Serializer.ArticleSerializer;
import ma.gestionjournale.gestionjournale_v1.enums.StatusArticle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@JsonSerialize(using = ArticleSerializer.class)
@Entity
@Data @NoArgsConstructor @AllArgsConstructor
public class Article {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "article_id")
    private Long id;
    private String titre;
    private String domaine;

    @Column(name = "mots_cles", nullable = false)
    private String mots_cles;

    private String resume;

    @Column(columnDefinition = "mediumtext")
    private String editorText;

    @JsonIgnore
    @Lob
    @Column(columnDefinition = "MEDIUMBLOB")
    private byte[] file;

    @Enumerated(EnumType.STRING)
    private StatusArticle status;

    private Date date_soumission;
    private Date date_acceptation;
    private Date date_modification;

    @ManyToOne
    private Auteur auteur_original;

    @OneToMany(mappedBy = "article_base")
    private List<Contribution> contributions;

    @OneToMany(mappedBy = "article")
    private List<Recommandation> recommandations;
}
