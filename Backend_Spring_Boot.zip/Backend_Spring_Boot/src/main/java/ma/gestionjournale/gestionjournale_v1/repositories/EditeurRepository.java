package ma.gestionjournale.gestionjournale_v1.repositories;

import ma.gestionjournale.gestionjournale_v1.entities.Editeur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EditeurRepository extends JpaRepository<Editeur, Long> {
}
