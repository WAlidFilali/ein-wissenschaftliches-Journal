package ma.gestionjournale.gestionjournale_v1;

import ma.gestionjournale.gestionjournale_v1.entities.Auteur;
import ma.gestionjournale.gestionjournale_v1.entities.Utilisateur;
import ma.gestionjournale.gestionjournale_v1.exceptions.UtilisateurNotFoundException;
import ma.gestionjournale.gestionjournale_v1.repositories.AuteurRepository;
import ma.gestionjournale.gestionjournale_v1.repositories.UtilisateurRepository;
import ma.gestionjournale.gestionjournale_v1.services.JournalServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.stream.Stream;

@SpringBootApplication
public class GestionJournaleV1Application {

    public static void main(String[] args) {
        SpringApplication.run(GestionJournaleV1Application.class, args);
    }

    @Bean
    CommandLineRunner start(UtilisateurRepository repository, AuteurRepository auteurRepository){
        return args -> {
            Stream.of("Walid", "Ali", "Bouchra", "Khadija").forEach( name -> {
                Utilisateur utilisateur = new Auteur();
                utilisateur.setNom(name);
                utilisateur.setPrenom("knia");
                utilisateur.setEmail(name+"@gmail.com");
                utilisateur.setTelephone("555-555-5555");

                repository.save(utilisateur);
                System.out.println("Utilisateur : "+name+" bien ajoutéé!");
            });
        };
    }
}
