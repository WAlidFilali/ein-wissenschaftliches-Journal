package ma.gestionjournale.gestionjournale_v1.exceptions;

public class RecommandationNotFoundException extends Exception {
    public RecommandationNotFoundException(String mess) {
        super(mess);
    }
}
