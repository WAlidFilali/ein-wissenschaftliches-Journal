package ma.gestionjournale.gestionjournale_v1.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.enums.StatusCompte;

import java.util.Date;
@Entity
@Data @NoArgsConstructor @AllArgsConstructor
public class Compte {
    @Id
    private String id;
    private String username;
    private String password;
    @Enumerated(EnumType.STRING)
    private StatusCompte status;
    private Date date_creation;
    private Date date_modification;

    @OneToOne
    private Utilisateur utilisateur;
}
