package ma.gestionjournale.gestionjournale_v1.entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.Serializer.ArticleSerializer;
import ma.gestionjournale.gestionjournale_v1.Serializer.RecommandationSerializer;

import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
//@JsonSerialize(using = RecommandationSerializer.class)
public class Recommandation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(columnDefinition = "TEXT")
    private String text_recommandation;

    private Date date_affectation;

    private Boolean decision;

    @ManyToOne
    private Examinateur examinateur;

    @ManyToOne
    private Article article;
}
