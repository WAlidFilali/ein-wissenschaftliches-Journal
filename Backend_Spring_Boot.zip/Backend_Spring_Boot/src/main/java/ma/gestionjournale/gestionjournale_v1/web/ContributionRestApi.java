package ma.gestionjournale.gestionjournale_v1.web;

import lombok.AllArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.entities.Article;
import ma.gestionjournale.gestionjournale_v1.entities.Contribution;
import ma.gestionjournale.gestionjournale_v1.exceptions.ArticleNotFoundException;
import ma.gestionjournale.gestionjournale_v1.exceptions.CodeNotFoundException;
import ma.gestionjournale.gestionjournale_v1.exceptions.ContributionNotFoundException;
import ma.gestionjournale.gestionjournale_v1.services.JournalServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@AllArgsConstructor
@CrossOrigin("*")

public class ContributionRestApi {
    private JournalServiceImpl journalService;

    @GetMapping("/contribution/{id}")
    public Contribution afficheContribution(@PathVariable(name = "id") Long id) throws ContributionNotFoundException {
        return journalService.getContribution(id);

    }

    @GetMapping("/contribution/{id}/code")
    public String getContributionCode(@RequestParam("code") String code,
                                      @PathVariable Long id) throws ContributionNotFoundException {
        Contribution contribution = journalService.getContribution(id);

        return contribution.getCode_unique();
    }

    @PostMapping("/contribution/searchCode")
    public Long searchContributionCode(@RequestBody String code) throws CodeNotFoundException, ArticleNotFoundException {
        System.out.println("code : "+code);
        List<Contribution> contributions = journalService.listeContribution();
        for (Contribution contribution : contributions) {
            System.out.println("Hana dkhlt lboucle!");
            if (contribution.getCode_unique().equals(code)) {
                Long id_article = contribution.getArticle_base().getId();
                System.out.println("id_article : "+id_article);
                return id_article;
            }

        }
        throw new CodeNotFoundException("Code saisi n'existe pas!");
    }

}
