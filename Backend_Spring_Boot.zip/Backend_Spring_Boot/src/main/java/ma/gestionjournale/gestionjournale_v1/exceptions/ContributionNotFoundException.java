package ma.gestionjournale.gestionjournale_v1.exceptions;

public class ContributionNotFoundException extends Exception {
    public ContributionNotFoundException(String s) {
        super(s);
    }
}
