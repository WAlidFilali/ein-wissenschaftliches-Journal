package ma.gestionjournale.gestionjournale_v1.exceptions;

public class ArticleNotFoundException extends Exception{
    public ArticleNotFoundException(String mess){
        super(mess);
    }
}
