package ma.gestionjournale.gestionjournale_v1.repositories;

import ma.gestionjournale.gestionjournale_v1.entities.Auteur;
import ma.gestionjournale.gestionjournale_v1.entities.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UtilisateurRepository extends JpaRepository<Utilisateur, Long> {
}
