package ma.gestionjournale.gestionjournale_v1.repositories;

import ma.gestionjournale.gestionjournale_v1.entities.Contribution;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContributionRepository extends JpaRepository<Contribution, Long> {
}
