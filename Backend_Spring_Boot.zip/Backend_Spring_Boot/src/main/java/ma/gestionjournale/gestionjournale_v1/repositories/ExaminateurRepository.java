package ma.gestionjournale.gestionjournale_v1.repositories;

import ma.gestionjournale.gestionjournale_v1.entities.Examinateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExaminateurRepository extends JpaRepository<Examinateur, Long> {
}
