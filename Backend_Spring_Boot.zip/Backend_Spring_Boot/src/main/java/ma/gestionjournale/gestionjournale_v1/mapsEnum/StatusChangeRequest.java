package ma.gestionjournale.gestionjournale_v1.mapsEnum;

import ma.gestionjournale.gestionjournale_v1.enums.StatusArticle;

public class StatusChangeRequest {
    private StatusArticle status;

    // Getters and Setters
    public StatusArticle getStatus() {
        return status;
    }

    public void setStatus(StatusArticle status) {
        this.status = status;
    }
}
