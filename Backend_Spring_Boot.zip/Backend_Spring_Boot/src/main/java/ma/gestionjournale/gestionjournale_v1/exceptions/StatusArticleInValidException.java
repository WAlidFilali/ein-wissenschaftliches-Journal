package ma.gestionjournale.gestionjournale_v1.exceptions;

public class StatusArticleInValidException extends Exception {
    public StatusArticleInValidException(String s) {
        super(s);
    }
}
