package ma.gestionjournale.gestionjournale_v1.repositories;

import ma.gestionjournale.gestionjournale_v1.entities.Recommandation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecommandationRepository extends JpaRepository<Recommandation, Long> {
}
