package ma.gestionjournale.gestionjournale_v1.Serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import ma.gestionjournale.gestionjournale_v1.entities.Article;

import java.io.IOException;
import java.util.Base64;

public class ArticleSerializer extends JsonSerializer<Article> {
    @Override
    public void serialize(Article article, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeStartObject();
        jsonGenerator.writeNumberField("id", article.getId());
        jsonGenerator.writeStringField("titre", article.getTitre());
        jsonGenerator.writeStringField("domaine", article.getDomaine());
        jsonGenerator.writeStringField("mots_cles", article.getMots_cles());
        jsonGenerator.writeStringField("resume", article.getResume());
        jsonGenerator.writeStringField("editorText", article.getEditorText());

        if (article.getFile() != null) {
            String base64File = Base64.getEncoder().encodeToString(article.getFile());
            jsonGenerator.writeStringField("file", base64File);
        }

        jsonGenerator.writeStringField("status", article.getStatus() != null ? article.getStatus().toString() : null);
        jsonGenerator.writeStringField("date_soumission", article.getDate_soumission() != null ? article.getDate_soumission().toString() : null);
        jsonGenerator.writeStringField("date_acceptation", article.getDate_acceptation() != null ? article.getDate_acceptation().toString() : null);
        jsonGenerator.writeStringField("date_modification", article.getDate_modification() != null ? article.getDate_modification().toString() : null);
        jsonGenerator.writeEndObject();
    }
}
