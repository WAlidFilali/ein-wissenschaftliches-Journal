package ma.gestionjournale.gestionjournale_v1.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor
public class Contribution {
    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY)
    private Long id;
    private String code_unique;
    private String description;
    private Date date_debut_contribution;
    private Date date_fin_contribution;

    @ManyToOne
    private Article article_base; //kola contributeurs binathum 3ndhum wa7d atricle de base khadamin 3liha "tous contibuteur ont une article de base ou ils travaillent"

    @ManyToOne
    private Auteur auteur_chef;
}
