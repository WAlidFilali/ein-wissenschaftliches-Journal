package ma.gestionjournale.gestionjournale_v1.web;

import lombok.AllArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.entities.Article;
import ma.gestionjournale.gestionjournale_v1.enums.StatusArticle;
import ma.gestionjournale.gestionjournale_v1.exceptions.ArticleNotFoundException;
import ma.gestionjournale.gestionjournale_v1.exceptions.StatusArticleInValidException;
import ma.gestionjournale.gestionjournale_v1.mapsEnum.StatusChangeRequest;
import ma.gestionjournale.gestionjournale_v1.services.JournalServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@AllArgsConstructor
@CrossOrigin("*")

public class ArticleRestApi {
    private JournalServiceImpl journalService;

    @GetMapping("/article/status")
    public List<String> ListeStatusArticle() {
        return Arrays.stream(StatusArticle.values()).map(StatusArticle::toString).collect(Collectors.toList());
    }

    @GetMapping("/article/status/{status}")
    public List<Article> ListeArticleParStatus(@PathVariable String status) {
        StatusArticle statusArticle = StatusArticle.valueOf(status);
        List<Article> articles = journalService.listeArticle();
        List<Article> articlesStatus = new ArrayList<>();
        for (Article article : articles) {
            if (article.getStatus().equals(statusArticle)) {
                articlesStatus.add(article);
            }
        }
        System.out.println("hana 3nroutourni lista ");
        return articlesStatus;
    }

    @GetMapping("/article/{id}/status")
    public ResponseEntity<Map<String, String>> getArticleStatus(@PathVariable Long id) throws ArticleNotFoundException {
        Article article = journalService.getArticle(id);
        Map<String, String> response = new HashMap<>();
        response.put("status", article.getStatus().toString());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/article/{id}/statusChange")
    public String modifierStatusArticle(@PathVariable Long id, @RequestBody String status) throws ArticleNotFoundException, StatusArticleInValidException {
        Article article = journalService.getArticle(id);
        try {
            StatusArticle statusArticle = StatusArticle.valueOf(status);
            article.setStatus(statusArticle);
            journalService.addArticle(article);
        } catch (IllegalArgumentException e) {
            throw new StatusArticleInValidException("Invalid status value: " + status);
        }
        System.out.println("Status of article " + id + " changed to: " + article.getStatus());
        return article.getStatus().toString();
    }



    @GetMapping("/article/{id}/editorContent")
    public String afficheArticleEditorContent(@PathVariable(name = "id") Long article_id) throws ArticleNotFoundException {
        Article articleDto = journalService.getArticle(article_id);
        return articleDto.getEditorText();

    }

    @PostMapping("/article/{id}/setContent")
    public String modifierArticleEditorContent(@PathVariable(name = "id") Long article_id, @RequestBody String contentEditor) throws ArticleNotFoundException {
        Article articleDto = journalService.getArticle(article_id);
        System.out.println("Ha lcontent: " + contentEditor);
        articleDto.setEditorText(contentEditor);
        journalService.addArticle(articleDto);
        return articleDto.getEditorText();

    }

    @GetMapping("/article/{id}")
    public Article afficheArticle(@PathVariable(name = "id") Long article_id) throws ArticleNotFoundException {
        System.out.println("the article will arrive sooner!");
        return journalService.getArticle(article_id);

    }

    @GetMapping("/article")
    public List<Article> listeArticle() {
        System.out.println("LISTE article!");
        return journalService.listeArticle();
    }

    //@PostMapping("/article/addWithPdf")
    @PostMapping("/article")
    public ResponseEntity<Article> addArticlePdf(@RequestParam String titre,
                                                 @RequestParam String domaine,
                                                 @RequestParam String resume,
                                                 @RequestParam String editorText,
                                                 @RequestParam String motscles,
                                                 @RequestPart(value = "file", required = false) MultipartFile file) throws IOException, IOException {
        Article article = new Article();
        article.setTitre(titre);
        article.setDomaine(domaine);
        article.setResume(resume);
        article.setMots_cles(motscles);
        article.setStatus(StatusArticle.BROUILLON);
        article.setDate_soumission(new Date());
        article.setEditorText("null".equals(editorText) ? null : editorText);

        if (file != null) {
            article.setFile(file.getBytes());
        }

        journalService.addArticle(article);
        return ResponseEntity.ok(article);
    }
}
