package ma.gestionjournale.gestionjournale_v1.services;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.entities.*;
import ma.gestionjournale.gestionjournale_v1.enums.StatusCompte;
import ma.gestionjournale.gestionjournale_v1.exceptions.*;
import ma.gestionjournale.gestionjournale_v1.repositories.*;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
@AllArgsConstructor
public class JournalServiceImpl implements IJournaleService{
    private CompteRepository compteRepository;
    private UtilisateurRepository utilisateurRepository;
    private AuteurRepository auteurRepository;
    private EditeurRepository editeurRepository;
    private ExaminateurRepository examinateurRepository;
    private ArticleRepository articleRepository;
    private ContributionRepository contributionRepository;
    private RecommandationRepository recommandationRepository;

//    private Utilisateur ajouterUtilisateur(Utilisateur utilisateur){
//        return utilisateurRepository.save(utilisateur);
//    }

    @Override
    public Utilisateur getUtilisateur(Long id) throws UtilisateurNotFoundException {

        return utilisateurRepository.findById(id).orElseThrow(()-> new UtilisateurNotFoundException("La utilisateur n'existe pas"));
    }

    @Override
    public List<Utilisateur> listeUtilisateur() {
        return utilisateurRepository.findAll();
    }

    @Override
    public Utilisateur ajouterUtilisateur(Utilisateur utilisateur) throws UtilisateurNotFoundException {

        if (utilisateur instanceof Auteur auteur) {
            auteur.setId(utilisateur.getId());
            auteur.setNom(utilisateur.getNom());
            auteur.setPrenom(utilisateur.getPrenom());
            auteur.setEmail(utilisateur.getEmail());
            auteur.setTelephone(utilisateur.getTelephone());
            auteur.setCompte(utilisateur.getCompte());

            auteur.setContributions(((Auteur) utilisateur).getContributions());

            auteur.setSpecialite(((Auteur) utilisateur).getSpecialite());
            auteur.setNbr_article_soumis(((Auteur) utilisateur).getNbr_article_soumis());
            auteur.setNbr_article_accepte(((Auteur) utilisateur).getNbr_article_accepte());

            return utilisateurRepository.save(auteur);
        } else if (utilisateur instanceof Editeur editeur) {
            editeur.setId(utilisateur.getId());
            editeur.setNom(utilisateur.getNom());
            editeur.setPrenom(utilisateur.getPrenom());
            editeur.setEmail(utilisateur.getEmail());
            editeur.setTelephone(utilisateur.getTelephone());
            editeur.setCompte(utilisateur.getCompte());

            return utilisateurRepository.save(editeur);
        } else if (utilisateur instanceof Examinateur examinateur) {
            examinateur.setId(utilisateur.getId());
            examinateur.setNom(utilisateur.getNom());
            examinateur.setPrenom(utilisateur.getPrenom());
            examinateur.setEmail(utilisateur.getEmail());
            examinateur.setTelephone(utilisateur.getTelephone());
            examinateur.setCompte(utilisateur.getCompte());

            examinateur.setNbr_article_affectes(((Examinateur) utilisateur).getNbr_article_affectes());
            examinateur.setNbr_article_evalues(((Examinateur) utilisateur).getNbr_article_evalues());

            return utilisateurRepository.save(examinateur);
        }

    return null;
    }

    @Override
    public void supprimerUtilisateur(Long id){
        utilisateurRepository.deleteById(id);
    }

    //------------Gestion listes des Acteur-----------------//

    @Override
    public List<Auteur> listeAuteur(){
        return auteurRepository.findAll();
    }

    @Override
    public List<Examinateur> listeExaminateur(){
        return examinateurRepository.findAll();
    }

    @Override
    public List<Editeur> listeEditeur(){
        return editeurRepository.findAll();
    }

    //------Gestion Compte----------//

    @Override
    public Compte ajouterCompte(Compte compte) throws NullUtilisateurException {
        if(compte.getUtilisateur() == null){
            throw new NullUtilisateurException("Il faut ajouter un utilisateur au compte!");
        }

        compte.setId(UUID.randomUUID().toString());
        compte.setDate_creation(new Date());
        compte.setStatus(StatusCompte.INACTIF);

        return compteRepository.save(compte);
    }

    @Override
    public Compte getCompte(String id) throws CompteNotFoundException {

        return compteRepository.findById(id).orElseThrow(()-> new CompteNotFoundException("Le compte n'existe pas"));
    }

    @Override
    public List<Compte> listeCompte(){

        return compteRepository.findAll();
    }

    @Override
    public Compte modifierCompte(String IDcompteOld, Compte compteNew) throws CompteNotFoundException {
        Compte compteOld = compteRepository.findById(IDcompteOld).orElse(null);

        if(compteOld == null){
            throw new CompteNotFoundException("Modification Echoué : Id compte introuvable!");
        }else{
            compteNew.setId(IDcompteOld);
            compteNew.setDate_creation(compteOld.getDate_creation());
            compteNew.setDate_modification(new Date());
            compteRepository.deleteById(IDcompteOld);

            return compteRepository.save(compteNew);
        }
    }

    @Override
    public void supprimerCompte(String id) {
        compteRepository.deleteById(id);
    }

    //-----------------Gestion Article ----------------//
    @Override
    public Article addArticle(Article article) {
        return articleRepository.save(article);
    }

    @Override
    public List<Article> listeArticle() {
        return articleRepository.findAll();
    }

    @Override
    public Article getArticle(Long id) throws ArticleNotFoundException {
        return articleRepository.findById(id).orElseThrow(()-> new ArticleNotFoundException("Article n'existe pas!"));
    }

    @Override
    public void supprimerArticle(Long id) {
        articleRepository.deleteById(id);
    }

    //---------Gestion Contibution--------------//
    @Override
    public Contribution getContribution(Long id) throws ContributionNotFoundException {
        return contributionRepository.findById(id).orElseThrow(()-> new ContributionNotFoundException("Contibution n'existe pas!"));
    }

    @Override
    public List<Contribution> listeContribution() {
        return contributionRepository.findAll();
    }

    //----------Gestion Recommendation---------------//
    @Override
    public Recommandation ajouterRecommandation(Recommandation recommandation) {
        return recommandationRepository.save(recommandation);
    }

    @Override
    public Recommandation getRecommandation(Long id) throws RecommandationNotFoundException {
        return recommandationRepository.findById(id).orElseThrow(()-> new RecommandationNotFoundException("Recommandation n'existe pas!"));
    }

    @Override
    public List<Recommandation> listeRecommandation() {
        return recommandationRepository.findAll();
    }
}
