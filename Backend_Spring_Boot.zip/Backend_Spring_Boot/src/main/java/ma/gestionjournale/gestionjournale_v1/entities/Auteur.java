package ma.gestionjournale.gestionjournale_v1.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.enums.SpecialiteAuteur;

import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Auteur extends Utilisateur{
    @Enumerated(EnumType.STRING)
    private SpecialiteAuteur specialite;
    private Long nbr_article_soumis;
    private Long nbr_article_accepte;

    @OneToMany(mappedBy = "auteur_original")
    private List<Article> articles;

    @OneToMany(mappedBy = "auteur_chef")
    private List<Contribution> contributions;
}
