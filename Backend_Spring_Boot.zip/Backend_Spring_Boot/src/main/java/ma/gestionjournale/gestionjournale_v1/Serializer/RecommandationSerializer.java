package ma.gestionjournale.gestionjournale_v1.Serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import ma.gestionjournale.gestionjournale_v1.entities.Recommandation;

import java.io.IOException;

public class RecommandationSerializer extends JsonSerializer<Recommandation> {
    @Override
    public void serialize(Recommandation recommandation, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeStartObject();
        jsonGenerator.writeNumberField("id", recommandation.getId());
        jsonGenerator.writeStringField("text_recommandation", recommandation.getText_recommandation());
        jsonGenerator.writeBooleanField("decision", recommandation.getDecision());


    }
}
