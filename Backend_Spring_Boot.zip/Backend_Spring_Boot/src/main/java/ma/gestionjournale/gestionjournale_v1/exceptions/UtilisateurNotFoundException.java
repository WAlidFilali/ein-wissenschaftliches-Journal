package ma.gestionjournale.gestionjournale_v1.exceptions;

public class UtilisateurNotFoundException extends Exception {
    public UtilisateurNotFoundException(String mess) {
        super(mess);
    }
}
