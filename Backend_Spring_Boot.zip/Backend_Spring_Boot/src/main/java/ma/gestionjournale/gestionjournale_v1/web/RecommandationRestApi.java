package ma.gestionjournale.gestionjournale_v1.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.entities.Article;
import ma.gestionjournale.gestionjournale_v1.entities.Recommandation;
import ma.gestionjournale.gestionjournale_v1.enums.StatusArticle;
import ma.gestionjournale.gestionjournale_v1.exceptions.ArticleNotFoundException;
import ma.gestionjournale.gestionjournale_v1.exceptions.RecommandationNotFoundException;
import ma.gestionjournale.gestionjournale_v1.exceptions.StatusArticleInValidException;
import ma.gestionjournale.gestionjournale_v1.services.JournalServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@AllArgsConstructor
@CrossOrigin("*")

public class RecommandationRestApi {
    private JournalServiceImpl journalService;

    @GetMapping("/recommandation")
    public List<Recommandation> ListeRecommendation() {
        return journalService.listeRecommandation();
    }

    @GetMapping("/recommandation/{id}")
    public Recommandation getRecommandation(@PathVariable Long id) throws RecommandationNotFoundException {
        return journalService.getRecommandation(id);
    }

    @PostMapping("/recommandation")
    public Recommandation ajouterRecommandation(@RequestParam(name = "text") String text,
                                                @RequestParam(name = "decision") boolean decision,
                                                @RequestParam(name = "article_id") Long article_id) throws RecommandationNotFoundException, ArticleNotFoundException {
//        ObjectMapper objectMapper = new ObjectMapper();
//        Article article;
//        try {
//            article = objectMapper.readValue(articleJson, Article.class);
//        } catch (IOException e) {
//            throw new RecommandationNotFoundException("Invalid article JSON");
//        }

        Article article = journalService.getArticle(article_id);

        Recommandation recommandation = new Recommandation();
        recommandation.setArticle(article);
        recommandation.setDecision(decision);
        recommandation.setText_recommandation(text);
        recommandation.setDate_affectation(new Date());
        System.out.println("NchaAllah nzidu Recommandation!");
        return journalService.ajouterRecommandation(recommandation);
    }



}
