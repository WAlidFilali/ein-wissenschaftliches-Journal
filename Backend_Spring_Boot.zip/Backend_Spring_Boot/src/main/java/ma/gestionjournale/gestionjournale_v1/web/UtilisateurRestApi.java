package ma.gestionjournale.gestionjournale_v1.web;

import lombok.AllArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.entities.Utilisateur;
import ma.gestionjournale.gestionjournale_v1.exceptions.UtilisateurNotFoundException;
import ma.gestionjournale.gestionjournale_v1.services.JournalServiceImpl;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@CrossOrigin("*")
public class UtilisateurRestApi {
    private JournalServiceImpl journalService;

    @GetMapping("/utilisateurs")
    public List<Utilisateur> listeUtilisateurs() {
        return journalService.listeUtilisateur();
    }

    @GetMapping("/utilisateurs/{id}")
    public Utilisateur getUtilisateur(@PathVariable Long id) throws UtilisateurNotFoundException {
        System.out.println("id = " + id);
        return journalService.getUtilisateur(id);
    }
}
