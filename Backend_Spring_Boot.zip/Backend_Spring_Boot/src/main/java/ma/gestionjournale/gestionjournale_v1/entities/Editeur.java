package ma.gestionjournale.gestionjournale_v1.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ma.gestionjournale.gestionjournale_v1.enums.SpecialiteAuteur;

import java.util.List;

@Entity
@Data

public class Editeur extends Utilisateur{
}
