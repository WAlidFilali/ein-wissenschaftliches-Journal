package ma.gestionjournale.gestionjournale_v1.services;

import ma.gestionjournale.gestionjournale_v1.entities.*;
import ma.gestionjournale.gestionjournale_v1.exceptions.*;

import java.util.List;

public interface IJournaleService {

    Utilisateur getUtilisateur(Long id) throws UtilisateurNotFoundException;

    List<Utilisateur> listeUtilisateur();

    Utilisateur ajouterUtilisateur(Utilisateur utilisateur) throws UtilisateurNotFoundException;

    void supprimerUtilisateur(Long id);

    List<Auteur> listeAuteur();

    List<Examinateur> listeExaminateur();

    List<Editeur> listeEditeur();

    Compte ajouterCompte(Compte compte) throws NullUtilisateurException;

    Compte getCompte(String id) throws CompteNotFoundException;

    List<Compte> listeCompte();

    Compte modifierCompte(String IDcompteOld, Compte compteNew) throws CompteNotFoundException;

    void supprimerCompte(String id);

    //-----------------Gestion Article ----------------//
    Article addArticle(Article article);

    List<Article> listeArticle();

    Article getArticle(Long id) throws ArticleNotFoundException;

    void supprimerArticle(Long id);

    //---------Gestion Contibution--------------//
    Contribution getContribution(Long id) throws ContributionNotFoundException;

    List<Contribution> listeContribution();

    //----------Gestion Recommendation---------------//
    Recommandation ajouterRecommandation(Recommandation recommandation);

    //----------Gestion Recommendation---------------//
    Recommandation getRecommandation(Long id) throws RecommandationNotFoundException;

    List<Recommandation> listeRecommandation();
}
