package ma.gestionjournale.gestionjournale_v1.exceptions;

public class CodeNotFoundException extends Exception{
    public CodeNotFoundException(String s) {
        super(s);
    }
}
