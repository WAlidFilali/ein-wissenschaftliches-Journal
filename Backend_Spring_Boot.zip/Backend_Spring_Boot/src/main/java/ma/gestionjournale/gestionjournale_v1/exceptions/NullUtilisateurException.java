package ma.gestionjournale.gestionjournale_v1.exceptions;

public class NullUtilisateurException extends Exception {
    public NullUtilisateurException(String mess) {
        super(mess);
    }
}
