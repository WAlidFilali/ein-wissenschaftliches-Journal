package ma.gestionjournale.gestionjournale_v1.exceptions;

public class CompteNotFoundException extends Exception {
    public CompteNotFoundException(String mess) {
        super(mess);
    }
}
